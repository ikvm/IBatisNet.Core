Technique for creating large sample test data from:

http://www.sql-server-performance.com/jc_large_data_operations.asp

Make sure you have enough space and have either enough processing power or 
enough patience to run the Embed Parameters in Statement tests.

Run embed-parameters-setup-init.sql prior to running tests.
