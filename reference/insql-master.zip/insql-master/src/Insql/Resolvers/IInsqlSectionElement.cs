﻿namespace Insql.Resolvers
{
    public interface IInsqlSectionElement
    {
        string Resolve(ResolveContext context);
    }
}