﻿using System;

namespace Insql.Tests.Models
{
    public class CommonDbContextTestsInfo : DbContextTestInfo
    {
    }
}
