﻿namespace Insql.Tests.Models
{
    public class FluentModelInfo
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int Size { get; set; }

        public string Extra { get; set; }
    }
}
