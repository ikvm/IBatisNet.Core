Building the Assemblies
----------------------------------------------


