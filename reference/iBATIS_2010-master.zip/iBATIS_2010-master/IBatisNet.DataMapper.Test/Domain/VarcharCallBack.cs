using System;
using System.Data;
using System.Data.SqlClient;
using IBatisNet.DataMapper.TypeHandlers;

namespace IBatisNet.DataMapper.Test.Domain
{

}
