﻿using Study.BusinessService.Application;
using Study.Entity;

namespace Study.BusinessService
{
    public interface IMoneyOutService : IServiceStudyBase<MoneyOutDto, MoneyOutQuery>
    {
        //Here add your service code
    }
}
