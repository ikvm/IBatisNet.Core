﻿using Study.BusinessService.Application;
using Study.Entity;

namespace Study.BusinessService
{
    public interface ISportRecordService : IServiceStudyBase<SportRecordDto, SportRecordQuery>
    {
        //Here add your service code
    }
}
