﻿using Study.BusinessService.Application;
using Study.Entity;

namespace Study.BusinessService
{
    public interface ISportKindService : IServiceStudyBase<SportKindDto, SportKindQuery>
    {
        //Here add your service code
    }
}
