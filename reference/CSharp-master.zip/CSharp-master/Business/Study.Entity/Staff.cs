﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Study.Entity
{
   public class Staff
    {
       public string STAFF_NAME { get; set; }
       public string STAFF_CARD_NO { get; set; }
       public string STAFF_BIRTH { get; set; }
       public string STAFF_PHONE { get; set; }
       public string HOME_ADDRESS { get; set; }
       public string GRADUATION_SCHOOL { get; set; }
       public string GRADUATION_DATE { get; set; }
       public string STAFF_MAJOR { get; set; }
       public string JOB_POSITION { get; set; }
       public string SEX { get; set; }
    }
}
