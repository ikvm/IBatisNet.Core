﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyUnitTest.UnitTest
{
    public class SportService : SecondBaseService, IExtendService
    {
    }
}
