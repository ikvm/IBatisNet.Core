
namespace MyBatis.DataMapper.SqlClient.Test.Domain
{
    public class Address
    {
        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        private string street;
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
    }
}
