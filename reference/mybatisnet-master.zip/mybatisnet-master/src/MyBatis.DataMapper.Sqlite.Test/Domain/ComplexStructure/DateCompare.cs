﻿namespace MyBatis.DataMapper.Sqlite.Test.Domain.ComplexStructure
{
    public class DateCompare
    {
        public int Day { get; set; }

        public int Month { get; set; }

        public int Year { get; set; }
    }
}