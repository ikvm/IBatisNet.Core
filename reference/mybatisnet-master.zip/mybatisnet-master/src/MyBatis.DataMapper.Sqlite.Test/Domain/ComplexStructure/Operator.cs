﻿namespace MyBatis.DataMapper.Sqlite.Test.Domain.ComplexStructure
{
    public enum Operator
    {
        And = 0,
        Or = 1
    }
}