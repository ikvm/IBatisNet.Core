namespace MyBatis.DataMapper.Sqlite.Test.Domain
{
	/// <summary>
	/// Summary description for E.
	/// </summary>
	public class E
	{
		private string _id;
		private string _libelle;

		public string Id
		{
			get { return _id; }
			set { _id = value; }
		}

		public string Libelle
		{
			get { return _libelle; }
			set { _libelle = value; }
		}
	}
}
