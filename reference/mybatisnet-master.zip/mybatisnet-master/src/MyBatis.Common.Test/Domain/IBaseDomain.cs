
using System;

namespace MyBatis.Common.Test.Domain
{
    public interface IBaseDomain
    {
        Guid Id { get; set; }
    } 

}
