using System.Collections.Generic;

namespace MyBatis.Common.Test.Domain
{
    public class GenericDocumentCollection : List<Document>
    {
    }
}

