using System;

namespace MyBatis.Common.Test.Domain
{
	/// <summary>
	/// Summary description for Order.
	/// </summary>
	public class Order
	{
		private Order()
		{
		}
	}
}
