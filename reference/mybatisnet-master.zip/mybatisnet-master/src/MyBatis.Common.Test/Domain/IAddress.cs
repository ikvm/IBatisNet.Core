

namespace MyBatis.Common.Test.Domain
{
    public interface IAddress : IBaseDomain
    {
        string Streetname { get; set; }
    } 
}
