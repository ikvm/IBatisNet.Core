This directory is where we'll hold the xsltproc libraries.

Windows
=======
To install on a Windows machine one needs to download the Windows binaries and libraries. 
These can be obtained from http://www.zlatkovic.com/pub/libxml/ or ftp://xmlsoft.org/win32/. 
Download the following: 
 
  
 iconv-1.9.1.win32.zip 
 libxml2-2.6.15.win32.zip 
 libxmlsec-1.2.6.win32.zip 
 libxslt-1.1.12.win32.zip 
 zlib-1.2.1.win32.zip 

Unzip all and put the content in the directoty.
 



