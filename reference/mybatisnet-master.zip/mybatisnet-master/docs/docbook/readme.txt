This directory is where we'll hold the Docbook reference libraries and DTD(Document Type Definition).

 http://www.docbook.org
