This directory is where we'll hold the Fop libraries.

FOP(Formatting Objects Processor) is used to transform FO files to files of other formats. 
In this tutorial it is used to transform FO output produced by xsltproc into PDF 
which is a well known format considered by many to be aesthetically pleasing. 
The Unix and Windows installation paths are very similar, the differences 
will be mentioned where appropriate. 

Download the latest version of the Fop application, from http://xml.apache.org/fop/. 


