
using System;

namespace IBatisNet.Common.Test.Domain
{
    public interface IBaseDomain
    {
        Guid Id { get; set; }
    } 

}
