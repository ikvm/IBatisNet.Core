﻿using System;

namespace Service.Model
{
    [Serializable]
    public class Entity
    {
  
    }

}
